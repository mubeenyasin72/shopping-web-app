import React, { Component } from 'react';
class makingCard extends Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            
        );
    }
}

export default makingCard;